module Napoli34 {
	requires javafx.controls;
	
	opens napoli34 to javafx.graphics, javafx.fxml;
}

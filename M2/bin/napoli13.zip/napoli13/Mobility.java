//***************************************************************************
// Mobility Interface for M2 Programming assignment                         *
// COP 2251                                                                 *
// By: Michael Napoli                                                       *
// January 23, 2023                                                         *
// Collaboration with: video notes chapter 13 and Oracle Java Documentation *
//***************************************************************************






package napoli13;

public interface Mobility {

	public abstract String move();
}
